package Mapas;
  public class coordenada{
    public double lat;
    public double lonj;
  }