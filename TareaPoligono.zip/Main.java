import java.util.*;
import Mapas.coordenada;

class Main {

  public static void Mapas() {
    ArrayList<coordenada> lista = new ArrayList<coordenada>();

    double Latitud, Longitud;
    int nCoordenada;
    Scanner input = new Scanner(System.in);

    System.out.println("Ingrese Coordenadas:");
    System.out.println("***************************");
    nCoordenada = input.nextInt();
    
    for (int x = 0; x < nCoordenada; x++) {
      System.out.println("");
      System.out.println("Ingrese Coordenada" + (x + 1));
      System.out.println("========================");
      System.out.println("Ingrese latitud " + (x + 1));
      Latitud = input.nextDouble();
      System.out.println("Ingrese longitud " + (x + 1));
      Longitud = input.nextDouble();

      coordenada o = new coordenada();
      o.lat = Latitud;
      o.lonj = Longitud;

      lista.add(x, o);

    }
    System.out.println("*************************************************");

    System.out.println("https://www.keene.edu/campus/maps/tool/?coordinates=");
    for (int x = 0; x <= nCoordenada; x++) {
      if (x != nCoordenada) {
        System.out.print(lista.get(x).lat);
        System.out.print("%2C%20");
        System.out.print(lista.get(x).lonj);
        System.out.print("%0A");
      } else {
        System.out.print(lista.get(0).lat);
        System.out.print("%2C%20");
        System.out.print(lista.get(0).lonj);
      }
    }
  }

  public static void main(String[] args) {
    System.out.println("");
    System.out.println("Desarrollo de un Poligono");
    System.out.println("***************************");
    System.out.println("");
    Mapas();

  }
}